export default function Hero() {
  return (
    <div className="bg-black text-white py-20">
      <div className="container mx-auto px-4 max-w-6xl">
        <p className="text-gray-300 text-lg leading-relaxed mb-20 font-[400]">
          Lenny Banks, a German investor and entrepreneur, specializes in crypto investing and decentralized finance,
          leveraging institutional strategies in global markets.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="border border-gray-800/50 p-12">
            <h2 className="text-3xl mb-4 font-[400] text-white">Banks Capital Blockchain Fund</h2>
            <p className="text-gray-300 text-lg font-[400]">
              Elite crypto venture firm investing in the next 100x opportunities, $30,000,000 AUM
            </p>
          </div>
          <div className="border border-gray-800/50 p-12">
            <h2 className="text-3xl mb-4 font-[400] text-white">Banks Research Group</h2>
            <p className="text-gray-300 text-lg font-[400]">Institutional-Grade Crypto Intelligence</p>
          </div>
          <div className="border border-gray-800/50 p-12">
            <h2 className="text-3xl mb-4 font-[400] text-white">Blockninja</h2>
            <p className="text-gray-300 text-lg font-[400]">
              Next-generation trading intelligence, redefining on-chain execution and market dominance.
            </p>
          </div>
          <div className="border border-gray-800/50 p-12">
            <h2 className="text-3xl mb-4 font-[400] text-white">Coin Whales</h2>
            <p className="text-gray-300 text-lg font-[400]">Private Network of high-end crypto investors</p>
          </div>
        </div>
      </div>
    </div>
  )
}

