import { Instagram, Twitter, Youtube } from "lucide-react"
import Link from "next/link"

export default function Footer() {
  return (
    <footer className="bg-black text-white pb-20">
      <div className="container mx-auto px-4 max-w-6xl">
        <div className="border border-gray-800/50 p-16 text-center">
          <h2 className="text-5xl mb-3 font-[400]">Lenny Banks</h2>
          <p className="text-gray-300 text-lg mb-10 font-[400]">Digital Investor, International Businessman, Creator</p>
          <div className="flex justify-center space-x-8">
            <Link
              href="https://x.com/thelennybanks"
              target="_blank"
              rel="noopener noreferrer"
              className="text-gray-500 hover:text-gray-300 transition-colors"
            >
              <Twitter className="w-6 h-6" />
              <span className="sr-only">Twitter</span>
            </Link>
            <Link
              href="https://www.youtube.com/@thebankscrypto"
              target="_blank"
              rel="noopener noreferrer"
              className="text-gray-500 hover:text-gray-300 transition-colors"
            >
              <Youtube className="w-6 h-6" />
              <span className="sr-only">YouTube</span>
            </Link>
            <Link
              href="https://www.instagram.com/thelennybanks/"
              target="_blank"
              rel="noopener noreferrer"
              className="text-gray-500 hover:text-gray-300 transition-colors"
            >
              <Instagram className="w-6 h-6" />
              <span className="sr-only">Instagram</span>
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}

