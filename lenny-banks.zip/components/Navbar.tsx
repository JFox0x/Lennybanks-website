import Link from "next/link"

export default function Navbar() {
  return (
    <nav className="bg-black text-white p-4">
      <div className="container mx-auto max-w-6xl">
        <Link href="/" className="block">
          <h1 className="text-2xl font-[400] text-white hover:text-gray-300 transition-colors">Lenny Banks</h1>
          <p className="text-sm text-gray-400 mt-1">Crypto Investor & Decentralized Finance Expert</p>
        </Link>
      </div>
    </nav>
  )
}

