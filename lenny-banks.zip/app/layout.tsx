import type React from "react"
import "./globals.css"
import { Playfair_Display } from "next/font/google"
import Navbar from "@/components/Navbar"

const playfair = Playfair_Display({
  subsets: ["latin"],
  display: "swap",
  weight: ["400", "500"],
  variable: "--font-playfair",
})

export const metadata = {
  title: "Lenny Banks | Crypto Investor & DeFi Expert",
  description:
    "Lenny Banks: German entrepreneur leveraging institutional strategies in crypto and DeFi, operating globally from Dubai and Europe.",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className={playfair.variable}>
      <body className="bg-black">
        <Navbar />
        {children}
      </body>
    </html>
  )
}



import './globals.css'